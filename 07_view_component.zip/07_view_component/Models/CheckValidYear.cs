﻿using System.ComponentModel.DataAnnotations;

namespace StarterM.Models
{
    public class CheckValidYear:ValidationAttribute
    {
        public CheckValidYear()
        {
            ErrorMessage = "The earliest opera is Daphne, 1598, by Corsi, Peri, and Rinuccini";

        }
        public override bool IsValid(object? value)
        {
            if (value == null) return true;

            int year=(int)value;

            return year>1597;
        }
    }
}
