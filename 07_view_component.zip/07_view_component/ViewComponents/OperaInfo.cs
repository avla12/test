﻿using Microsoft.AspNetCore.Mvc;
using StarterM.Data;

namespace StarterM.ViewComponents
{
    public class OperaInfo : ViewComponent
    {
        readonly OperaContext _context;
        public OperaInfo(OperaContext context)
        {
            _context = context;
        }
        public async Task<IViewComponentResult> InvokeAsync(int id)
        {
            var opera = await _context.Operas.FindAsync(id);
            if (opera == null)
            {
                //return Content("None...");
                //return Content("<h3 style='color:red'>None...</h3>");
                return View("NotFound");
            }
            // return View(opera);
            return View("~/Views/Shared/_OperaInfo.cshtml",opera);
        }
    }
}
