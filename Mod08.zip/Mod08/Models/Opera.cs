﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StarterM.Models
{
    public class Opera
    {
        [Display(Name = "編號")]     
        public int OperaID { get; set; }

        [Required(ErrorMessage = "歌劇名稱不可以為空白")]
        [StringLength(200)]
        [Display(Name = "歌劇名稱")]
        public string Title { get; set; } = null!;

        [Display(Name = "年代")]
        [CheckValidYear]
        public int? Year { get; set; }

        [Required]
        [Display(Name = "作者")]
        [Remote("VerifySpecialChars", "Opera")]
        public string? Composer { get; set; }

        [ValidateNever]
        public virtual ICollection<Comment> Comments { get; set; } = null!;
    }
}
