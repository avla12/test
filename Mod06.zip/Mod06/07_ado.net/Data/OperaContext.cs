﻿using Microsoft.EntityFrameworkCore;
using StarterM.Models;

namespace StarterM.Data
{
    public class OperaContext : DbContext
    {
        public OperaContext(DbContextOptions<OperaContext> options) : base(options) { }

        public DbSet<Opera> Operas { get; set; }
        public DbSet<Comment>  Comments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Opera>().HasData(
                new Opera
                {
                    OperaID = 1,
                    Title = "Cosi Fan Tutte",
                    Year = 1790,
                    Composer = "Wolfgang Amadeus Mozart",
                },
                   new Opera
                   {
                       OperaID = 2,
                       Title = "Rigoletto",
                       Year = 1851,
                       Composer = "Giuseppe Verdi",
                   },
                   new Opera
                   {
                       OperaID = 3,
                       Title = "Nixon in China",
                       Year = 1987,
                       Composer = "John Adams"
                   },
                   new Opera
                   {
                       OperaID = 4,
                       Title = "Wozzeck",
                       Year = 1922,
                       Composer = "Alban Berg"
                   },
                        new Opera
                        {
                            OperaID = 5,
                            Title = "Cosi Fan Tutte2",
                            Year = 1790,
                            Composer = "Wolfgang Amadeus Mozart",
                        },
               new Opera
               {
                   OperaID = 6,
                   Title = "Rigoletto2",
                   Year = 1851,
                   Composer = "Giuseppe Verdi",
               },
               new Opera
               {
                   OperaID = 7,
                   Title = "Nixon in China2",
                   Year = 1987,
                   Composer = "John Adams"
               },
               new Opera
               {
                   OperaID = 8,
                   Title = "Wozzeck2",
                   Year = 1922,
                   Composer = "Alban Berg"
               },
                new Opera
                {
                    OperaID = 9,
                    Title = "Cosi Fan Tutte3",
                    Year = 1790,
                    Composer = "Wolfgang Amadeus Mozart",
                },
               new Opera
               {
                   OperaID = 10,
                   Title = "Rigoletto3",
                   Year = 1851,
                   Composer = "Giuseppe Verdi",
               },
               new Opera
               {
                   OperaID = 11,
                   Title = "Nixon in China3",
                   Year = 1987,
                   Composer = "John Adams"
               },
               new Opera
               {
                   OperaID = 12,
                   Title = "Wozzeck3",
                   Year = 1922,
                   Composer = "Alban Berg"
               },
                new Opera
                {
                    OperaID = 13,
                    Title = "Cosi Fan Tutte4",
                    Year = 1790,
                    Composer = "Wolfgang Amadeus Mozart",
                },
               new Opera
               {
                   OperaID = 14,
                   Title = "Rigoletto4",
                   Year = 1851,
                   Composer = "Giuseppe Verdi",
               },
               new Opera
               {
                   OperaID = 15,
                   Title = "Nixon in China4",
                   Year = 1987,
                   Composer = "John Adams"
               },
               new Opera
               {
                   OperaID = 16,
                   Title = "Wozzeck4",
                   Year = 1922,
                   Composer = "Alban Berg"
               }


                   );
            modelBuilder.Entity<Comment>().HasData(
    new() { CommentId = 1, OperaID = 1, UserName = "user1", UserComment = "comment1", LastModified = DateTime.Now },
    new() { CommentId = 2, OperaID = 1, UserName = "user2", UserComment = "comment2", LastModified = DateTime.Now },
    new() { CommentId = 3, OperaID = 2, UserName = "user3", UserComment = "comment3", LastModified = DateTime.Now },
    new() { CommentId = 4, OperaID = 2, UserName = "user4", UserComment = "comment4", LastModified = DateTime.Now }
    );
        }
    }
}
