﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace StarterM.Migrations
{
    /// <inheritdoc />
    public partial class SeedDataComment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Comments",
                columns: new[] { "CommentId", "LastModified", "OperaID", "UserComment", "UserName" },
                values: new object[,]
                {
                    { 1, new DateTime(2024, 5, 12, 9, 3, 30, 386, DateTimeKind.Local).AddTicks(6293), 1, "comment1", "user1" },
                    { 2, new DateTime(2024, 5, 12, 9, 3, 30, 386, DateTimeKind.Local).AddTicks(6304), 1, "comment2", "user2" },
                    { 3, new DateTime(2024, 5, 12, 9, 3, 30, 386, DateTimeKind.Local).AddTicks(6305), 2, "comment3", "user3" },
                    { 4, new DateTime(2024, 5, 12, 9, 3, 30, 386, DateTimeKind.Local).AddTicks(6306), 2, "comment4", "user4" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Comments",
                keyColumn: "CommentId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Comments",
                keyColumn: "CommentId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Comments",
                keyColumn: "CommentId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Comments",
                keyColumn: "CommentId",
                keyValue: 4);
        }
    }
}
