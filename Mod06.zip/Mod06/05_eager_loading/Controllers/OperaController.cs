﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StarterM.Data;
using System.Text.RegularExpressions;


namespace StarterM.Controllers
{
    public class OperaController : Controller
    {
        readonly OperaContext _context; //field 

        public OperaController(OperaContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index(string q, string sortOrder, int page=1)
        {
            var query = _context.Operas.AsQueryable();
            if (!string.IsNullOrEmpty(q))
            {
                query = query.Where(o => o.Title.Contains(q));
            }
            //------------------------------------
            ViewBag.titleSort = sortOrder == "title" ? "title_desc" : "title";
            ViewBag.yearSort = sortOrder == "year" ? "year_desc" : "year";
            //============
            ViewBag.q = q;
            ViewBag.sortOrder = sortOrder;
            //============

            //switch expression
            query = sortOrder switch
            {
                "title" => query.OrderBy(o => o.Title),
                "title_desc" => query.OrderByDescending(o => o.Title),
                "year" => query.OrderBy(o => o.Year),
                "year_desc" => query.OrderByDescending(o => o.Year),
                _ => query.OrderBy(o => o.OperaID)
            };
            //---------------------------------
            return View(await PaginatedList<Opera>.CreateAsync(
                query,page,5));
        }

        private bool OperaExists(int id)
        {
            return _context.Operas.Any(e => e.OperaID == id);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Opera opera)
        {
            if (id != opera.OperaID)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Operas.Update(opera);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    if (!OperaExists(id))
                    {
                        //return NotFound();
                        ModelState.AddModelError(string.Empty, ex.Message);
                        return View(opera);
                    }

                    throw;
                }
             
            }
            return View(opera);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            return View(opera);
        }
        [HttpPost]
        [ActionName(nameof(Delete))]
        public async Task<IActionResult> DeleteConfirm(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            _context.Operas.Remove(opera);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

    
        public async Task<IActionResult> Delete2(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            _context.Operas.Remove(opera);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            return View(opera);
        }
      
        public IActionResult VerifySpecialChars(string composer)
        {
            Regex regex = new(@"[^a-zA-Z0-9\s]");
            if (regex.IsMatch(composer))
            {
                return Json($" 作者不可包含特殊字元，只允許字母、數字和空白 : {composer}");
            }
            return Json(true);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task< IActionResult> Create(Opera opera)
        {
            if(ModelState.IsValid)
            {
                _context.Operas.Add(opera);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddModelError(string.Empty, "xyz..."); //Model Error
            return View(opera);
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera =await _context.Operas.Include(o=>o.Comments)
                .FirstOrDefaultAsync(o => o.OperaID == id);
            if (opera == null)
            { 
                return NotFound();
            }
            return View(opera);
        }
     

    }
}
