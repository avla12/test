﻿using Microsoft.AspNetCore.Mvc;
using StarterM.Models;

namespace StarterM.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee emp)
        {
            ViewBag.result = $@"Employee id : {emp.EmployeeId}
Employee Name : {emp.EmployeeName}
Birth Date : {emp.BirthDate:d}";

            return View();
        }
    }
}
