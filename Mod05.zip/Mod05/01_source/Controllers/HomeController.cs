﻿using Microsoft.AspNetCore.Mvc;

namespace StarterM.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index([FromQuery]string id,
           [FromHeader] string accept,
           [FromHeader(Name = "User-Agent")]  string UserAgent)
        {
            ViewBag.Id = id;
            ViewBag.Accept = accept;
            ViewBag.UserAgent = UserAgent;
            return View();
        }
    }
}
