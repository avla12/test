﻿using Microsoft.AspNetCore.Mvc;

namespace StarterM.Controllers
{
    public class HomeController : Controller
    {
        [BindProperty(SupportsGet =true)]
        [ViewData]
        public string? Message { get; set; }
        public IActionResult Index()
        {       
            return View();
        }
    }
}
