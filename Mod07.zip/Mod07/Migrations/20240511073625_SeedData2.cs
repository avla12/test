﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace StarterM.Migrations
{
    /// <inheritdoc />
    public partial class SeedData2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Operas",
                columns: new[] { "OperaID", "Composer", "Title", "Year" },
                values: new object[,]
                {
                    { 5, "Wolfgang Amadeus Mozart", "Cosi Fan Tutte2", 1790 },
                    { 6, "Giuseppe Verdi", "Rigoletto2", 1851 },
                    { 7, "John Adams", "Nixon in China2", 1987 },
                    { 8, "Alban Berg", "Wozzeck2", 1922 },
                    { 9, "Wolfgang Amadeus Mozart", "Cosi Fan Tutte3", 1790 },
                    { 10, "Giuseppe Verdi", "Rigoletto3", 1851 },
                    { 11, "John Adams", "Nixon in China3", 1987 },
                    { 12, "Alban Berg", "Wozzeck3", 1922 },
                    { 13, "Wolfgang Amadeus Mozart", "Cosi Fan Tutte4", 1790 },
                    { 14, "Giuseppe Verdi", "Rigoletto4", 1851 },
                    { 15, "John Adams", "Nixon in China4", 1987 },
                    { 16, "Alban Berg", "Wozzeck4", 1922 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Operas",
                keyColumn: "OperaID",
                keyValue: 16);
        }
    }
}
