﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StarterM.Data;

namespace StarterM.Controllers
{
    public class CommentController : Controller
    {
        readonly OperaContext _context;

        public CommentController(OperaContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Details(int? id)
        {
            var c=await _context.Comments.FindAsync(id);
            return View(c);
        }

        //public async Task<IActionResult> Details(int? id)
        //{
        //    using var cn = new SqlConnection(_context.Database.GetConnectionString());

        //    using var cmd = new SqlCommand("SELECT * FROM Comments where CommentId=@id", cn);
        //    cmd.Parameters.AddWithValue("@id", id);
        //    await cn.OpenAsync();
        //    using var dr = await cmd.ExecuteReaderAsync();

        //    await dr.ReadAsync();
        //    Comment c = new()
        //    {
        //        CommentId = dr.GetInt32(0),
        //        UserName = dr.GetString(1),
        //        UserComment = (string)dr["UserComment"],
        //        LastModified = dr.GetDateTime(3),
        //        OperaID =dr.GetInt32(4),
        //    };
        //    return View(c);
        //}

    }
}
