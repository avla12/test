﻿namespace StarterM.Models
{
    public class Comment
    {
        public int CommentId { get; set; }
        public string UserName { get; set; } = null!;
        public string UserComment { get; set; } = null!;
        public DateTime LastModified { get; set; }
        public int OperaID { get; set; }
        public virtual Opera Opera { get; set; } = null!;

    }
}
