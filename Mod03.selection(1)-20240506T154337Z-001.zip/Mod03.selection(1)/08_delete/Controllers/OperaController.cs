﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StarterM.Data;
using System.Text.RegularExpressions;


namespace StarterM.Controllers
{
    public class OperaController : Controller
    {
        readonly OperaContext _context; //field 

        public OperaController(OperaContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            return View(opera);
        }
        [HttpPost]
        [ActionName(nameof(Delete))]
        public async Task<IActionResult> DeleteConfirm(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            _context.Operas.Remove(opera);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

    
        public async Task<IActionResult> Delete2(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            _context.Operas.Remove(opera);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera = await _context.Operas
                .FindAsync(id);
            if (opera == null)
            {
                return NotFound();
            }
            return View(opera);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(int id,Opera opera)
        {
            if (id != opera.OperaID)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                _context.Operas.Update(opera);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }           
            return View(opera);
        }
        public IActionResult VerifySpecialChars(string composer)
        {
            Regex regex = new(@"[^a-zA-Z0-9\s]");
            if (regex.IsMatch(composer))
            {
                return Json($" 作者不可包含特殊字元，只允許字母、數字和空白 : {composer}");
            }
            return Json(true);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task< IActionResult> Create(Opera opera)
        {
            if(ModelState.IsValid)
            {
                _context.Operas.Add(opera);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddModelError(string.Empty, "xyz..."); //Model Error
            return View(opera);
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            Opera? opera =await _context.Operas
                .FirstOrDefaultAsync(o => o.OperaID == id);
            if (opera == null)
            { 
                return NotFound();
            }
            return View(opera);
        }
        public async Task<IActionResult> Index()
        {
            return View(await _context.Operas.ToListAsync());

        }

    }
}
